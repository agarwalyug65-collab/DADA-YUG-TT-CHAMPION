/** DOM layer: menu, scoreboard, messages, charge meter. */
export class UI {
  constructor() {
    this.$ = id => document.getElementById(id);
    this.difficulty = 'medium';
    this.onStart = null;
    this.timer = null;
    const btns = document.querySelectorAll('[data-diff]');
    btns.forEach(b => b.onclick = () => {
      this.difficulty = b.dataset.diff;
      btns.forEach(x => x.classList.toggle('on', x === b));
    });
    this.$('start').onclick = () => this.onStart?.(this.difficulty);
  }
  score(p, a, server) {
    this.$('sp').textContent = p;
    this.$('sa').textContent = a;
    this.$('serve').textContent = server === 'player' ? '● Your serve' : '● CPU serve';
  }
  message(text, ms = 1400) {
    const m = this.$('msg');
    m.textContent = text; m.classList.add('show');
    clearTimeout(this.timer);
    if (ms) this.timer = setTimeout(() => m.classList.remove('show'), ms);
  }
  charge(v) {
    this.$('charge').classList.toggle('hidden', v <= 0);
    this.$('chargeFill').style.width = `${v * 100}%`;
  }
  showMenu(title, sub, btn) {
    this.$('menu').querySelector('h1').innerHTML = `${title}<span>.</span>`;
    this.$('sub').textContent = sub;
    this.$('start').textContent = btn;
    this.$('menu').classList.remove('hidden');
    this.$('hud').classList.add('hidden');
  }
  hideMenu() {
    this.$('menu').classList.add('hidden');
    this.$('hud').classList.remove('hidden');
  }
}
