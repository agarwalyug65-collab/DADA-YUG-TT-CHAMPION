import * as THREE from 'three';

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/** speed: paddle m/s · err: aim error (m) · react: reaction delay (s) · power: 0..1 */
export const LEVELS = {
  easy:   { speed: 1.5, err: 0.22, react: 0.45, power: 0.45, reach: 0.10, smart: false },
  medium: { speed: 2.6, err: 0.10, react: 0.25, power: 0.65, reach: 0.125, smart: false },
  hard:   { speed: 4.2, err: 0.03, react: 0.10, power: 0.90, reach: 0.15, smart: true }
};

/** Predicts the intercept by simulating the ball forward, then moves the paddle at limited speed. */
export class AI {
  constructor(level = 'medium') {
    this.cfg = LEVELS[level];
    this.target = new THREE.Vector2(0, 0.25);
    this.err = new THREE.Vector2();
    this.delay = 0;
  }
  notifyHit() {
    this.delay = this.cfg.react;
    const e = this.cfg.err;
    this.err.set((Math.random() * 2 - 1) * e, (Math.random() * 2 - 1) * e * 0.6);
  }
  get power() { return this.cfg.power * (0.85 + Math.random() * 0.15); }
  aim(playerX) { return this.cfg.smart ? -Math.sign(playerX || 1) * 0.5 : (Math.random() * 2 - 1) * 0.55; }
  predict(ball, z) {
    const b = ball.clone();
    for (let i = 0; i < 400 && b.pos.z > z && b.pos.y > -0.5; i++) b.step(1 / 120);
    return new THREE.Vector2(b.pos.x, b.pos.y);
  }
  update(dt, ball, paddle, incoming) {
    if (incoming) {
      this.delay -= dt;
      if (this.delay <= 0) this.target.copy(this.predict(ball, paddle.pos.z)).add(this.err);
    } else this.target.set(0, 0.25);
    this.target.x = clamp(this.target.x, -1.1, 1.1);
    this.target.y = clamp(this.target.y, 0.04, 0.6);
    const dx = this.target.x - paddle.pos.x, dy = this.target.y - paddle.pos.y;
    const d = Math.hypot(dx, dy), s = Math.min(d, this.cfg.speed * dt);
    if (d > 1e-6) { paddle.pos.x += (dx / d) * s; paddle.pos.y += (dy / d) * s; }
  }
}
