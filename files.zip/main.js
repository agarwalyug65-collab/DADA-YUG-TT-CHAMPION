import { Game } from './game.js';
import { UI } from './ui.js';
import { Sfx } from './audio.js';

const ui = new UI();
const sfx = new Sfx();
const game = new Game(document.getElementById('scene'), ui, sfx);
ui.onStart = level => { sfx.unlock(); game.start(level); };
