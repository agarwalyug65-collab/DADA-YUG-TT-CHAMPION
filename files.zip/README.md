# Rally — 3D Table Tennis

A browser-based 3D table tennis game with spin physics (topspin, backspin, sidespin), an AI opponent with three difficulty levels, bloom post-processing, and fully synthesized audio. No build step required.

**Live demo:** `https://<your-username>.github.io/<repo-name>/` *(replace after enabling GitHub Pages)*

## Tech Stack
- [Three.js](https://threejs.org) r168 — rendering, shadows, ACES tone mapping, `UnrealBloomPass`, environment reflections (loaded via import map from jsDelivr)
- Custom physics (`src/physics.js`) — gravity, quadratic drag, Magnus force, spin-aware table bounce, net collision
- Web Audio API — synthesized hit / bounce / score sounds
- Vanilla ES modules, HTML5 Canvas, CSS3 (Outfit via Google Fonts)

## Controls
| Action | Mouse | Keyboard |
|---|---|---|
| Move paddle | Move cursor | `WASD` / arrow keys |
| Swing | Hold click to charge, release to hit | Hold `Space`, release to hit |
| Serve | Same as swing when it's your serve | Same |

Not swinging gives a weak block. Swing **upward** through the ball for topspin, **downward** for backspin, and move **sideways** for curve.

## Rules
First to 11 points, win by 2. Service alternates every 2 points, and every point from 10–10.

## Local Setup
```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
python3 -m http.server 8000      # or: npm start
```
Open `http://localhost:8000`. (ES modules require a server; opening `index.html` via `file://` won't work.)

## Deploy
Push to GitHub, then **Settings → Pages → Deploy from branch → `main` / root**.

## Structure
```
index.html   style.css
src/main.js      bootstrap
src/game.js      scene, rules, game loop
src/physics.js   ball physics + strike solver
src/ai.js        opponent + difficulty presets
src/controls.js  mouse/keyboard input
src/ui.js        menu, HUD
src/audio.js     synthesized sound
```

## License
MIT
