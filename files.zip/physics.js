import * as THREE from 'three';

/** Units are metres. Table top is y=0, net at z=0, player on +z. */
export const TABLE = { hl: 1.37, hw: 0.7625, netH: 0.1525, floorY: -0.76 };
export const BALL_R = 0.02;
const G = 9.81, MAGNUS = 0.006, DRAG = 0.12, E_TABLE = 0.92, MU = 0.18;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/** Ball with gravity, quadratic air drag, Magnus force (spin) and spin-aware table bounce. */
export class Ball {
  constructor() {
    this.pos = new THREE.Vector3(); this.vel = new THREE.Vector3(); this.spin = new THREE.Vector3();
  }
  clone() {
    const b = new Ball();
    b.pos.copy(this.pos); b.vel.copy(this.vel); b.spin.copy(this.spin);
    return b;
  }
  /** Advance by dt; returns events: {type:'table',side} | {type:'net'} | {type:'floor'} */
  step(dt) {
    const ev = [], p = this.pos, v = this.vel, s = this.spin;
    const m = new THREE.Vector3().crossVectors(s, v).multiplyScalar(MAGNUS);
    const d = DRAG * v.length();
    v.x += (m.x - d * v.x) * dt;
    v.y += (m.y - d * v.y - G) * dt;
    v.z += (m.z - d * v.z) * dt;
    const pz = p.z;
    p.addScaledVector(v, dt);

    // Net: crossing the z=0 plane below the net top
    if ((pz > 0) !== (p.z > 0) && Math.abs(p.x) < TABLE.hw + 0.15 && p.y > 0 && p.y < TABLE.netH + BALL_R) {
      p.z = pz > 0 ? 0.015 : -0.015;
      v.z *= -0.25; v.x *= 0.5; s.multiplyScalar(0.5);
      ev.push({ type: 'net' });
    }
    // Table: restitution + friction coupled to spin
    if (p.y <= BALL_R && p.y > -0.05 && v.y < 0 && Math.abs(p.x) < TABLE.hw && Math.abs(p.z) < TABLE.hl) {
      p.y = BALL_R; v.y *= -E_TABLE;
      const cx = v.x + s.z * BALL_R, cz = v.z - s.x * BALL_R; // contact-point slip velocity
      v.x -= MU * cx; v.z -= MU * cz;
      s.x += (0.75 / BALL_R) * MU * cz;
      s.z -= (0.75 / BALL_R) * MU * cx;
      if (s.length() > 150) s.setLength(150);
      ev.push({ type: 'table', side: p.z > 0 ? 'player' : 'ai' });
    }
    // Floor
    if (p.y < TABLE.floorY + BALL_R && v.y < 0) {
      p.y = TABLE.floorY + BALL_R; v.y *= -0.55; v.x *= 0.8; v.z *= 0.8;
      ev.push({ type: 'floor' });
    }
    return ev;
  }
}

/**
 * Paddle strike. Solves the launch velocity so the ball lands at a depth
 * set by `power` and at `aimX`, while clearing the net. Paddle velocity `pv`
 * imparts spin (up = topspin, down = backspin, sideways = sidespin).
 * dir: -1 = towards the AI, +1 = towards the player.
 */
export function strike(ball, dir, power, aimX, pv) {
  const vz = dir * (2.6 + 5.2 * power), tz = dir * (0.4 + 0.7 * power);
  const t = Math.max(0.2, (tz - ball.pos.z) / vz), y0 = ball.pos.y - BALL_R;
  let vy = (4.9 * t * t - y0) / t;
  const tn = Math.max(0.05, Math.abs(ball.pos.z / vz));
  vy = Math.max(vy, (TABLE.netH + 0.08 - y0 + 4.9 * tn * tn) / tn);
  ball.vel.set(clamp((aimX - ball.pos.x) / t, -3, 3), vy, vz * 1.03);
  ball.spin.set(clamp(dir * pv.y * 40, -100, 100), clamp(pv.x * 30, -80, 80), 0);
}
