const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/** Mouse + keyboard input. x in [-1,1], y in [0,1]. Hold to charge, release to swing. */
export class Controls {
  constructor(el) {
    this.x = 0; this.y = 0.4; this.charge = 0; this.charging = false;
    this.onRelease = null; this.keys = {};
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect();
      this.x = ((e.clientX - r.left) / r.width) * 2 - 1;
      this.y = 1 - (e.clientY - r.top) / r.height;
    });
    el.addEventListener('pointerdown', () => this.press());
    addEventListener('pointerup', () => this.release());
    addEventListener('keydown', e => {
      if (e.code === 'Space') { e.preventDefault(); if (!e.repeat) this.press(); }
      this.keys[e.code] = true;
    });
    addEventListener('keyup', e => {
      if (e.code === 'Space') this.release();
      this.keys[e.code] = false;
    });
  }
  press() { this.charging = true; this.charge = 0; }
  release() {
    if (!this.charging) return;
    this.charging = false;
    this.onRelease?.(0.3 + 0.7 * this.charge);
    this.charge = 0;
  }
  update(dt) {
    if (this.charging) this.charge = Math.min(1, this.charge + dt * 1.4);
    const k = this.keys;
    const dx = (k.ArrowRight || k.KeyD ? 1 : 0) - (k.ArrowLeft || k.KeyA ? 1 : 0);
    const dy = (k.ArrowUp || k.KeyW ? 1 : 0) - (k.ArrowDown || k.KeyS ? 1 : 0);
    this.x = clamp(this.x + dx * dt * 1.8, -1, 1);
    this.y = clamp(this.y + dy * dt * 1.2, 0, 1);
  }
}
