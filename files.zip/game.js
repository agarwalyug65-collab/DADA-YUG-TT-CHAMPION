import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Ball, TABLE, BALL_R, strike } from './physics.js';
import { AI } from './ai.js';
import { Controls } from './controls.js';

const PADDLE_Z = 1.55, WIN = 11;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const other = s => (s === 'player' ? 'ai' : 'player');

/** States: menu → serve → rally → point → serve … → over */
export class Game {
  constructor(canvas, ui, sfx) {
    this.ui = ui; this.sfx = sfx;
    this.state = 'menu'; this.first = 'player';
    this.score = { player: 0, ai: 0 };
    this.ball = new Ball(); this.cool = 0; this.wait = 0; this.timer = 0;
    this.lastHitter = null; this.bouncedOpp = false;
    this.ai = new AI('medium');
    this.controls = new Controls(canvas);
    this.controls.onRelease = p => this.onSwing(p);
    this.buildScene(canvas);
    this.pp = this.makePaddle(0xd7263d, PADDLE_Z);
    this.ap = this.makePaddle(0x2b303a, -PADDLE_Z);
    addEventListener('resize', () => this.resize());
    this.resize();
    this.last = performance.now();
    requestAnimationFrame(t => this.frame(t));
  }

  // ---------- scene ----------
  buildScene(canvas) {
    const R = this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    R.setPixelRatio(Math.min(devicePixelRatio, 2));
    R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFSoftShadowMap;
    R.toneMapping = THREE.ACESFilmicToneMapping;
    const S = this.scene = new THREE.Scene();
    S.background = new THREE.Color(0x0d1117); S.fog = new THREE.Fog(0x0d1117, 6, 14);
    S.environment = new THREE.PMREMGenerator(R).fromScene(new RoomEnvironment(), 0.04).texture;
    S.environmentIntensity = 0.35;
    this.camera = new THREE.PerspectiveCamera(50, 1, 0.1, 40);

    S.add(new THREE.HemisphereLight(0xbfd4ff, 0x20242c, 0.6));
    const sun = new THREE.DirectionalLight(0xfff1de, 2.2);
    sun.position.set(2, 4, 2); sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048); sun.shadow.bias = -0.0004;
    Object.assign(sun.shadow.camera, { left: -2.5, right: 2.5, top: 2.5, bottom: -2.5, near: 0.5, far: 12 });
    S.add(sun);

    const std = (color, rough = 0.5, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
    const box = (w, h, d, mat, x, y, z, shadow = true) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, y, z); m.castShadow = shadow; m.receiveShadow = true; S.add(m); return m;
    };
    const floor = new THREE.Mesh(new THREE.CircleGeometry(12, 48), std(0x151a22, 0.85));
    floor.rotation.x = -Math.PI / 2; floor.position.y = TABLE.floorY; floor.receiveShadow = true; S.add(floor);

    box(TABLE.hw * 2, 0.04, TABLE.hl * 2, std(0x1d4e89, 0.28, 0.05), 0, -0.02, 0);
    const white = std(0xf4f6f8, 0.5);
    [-1, 1].forEach(s => {
      box(0.02, 0.002, TABLE.hl * 2, white, s * (TABLE.hw - 0.01), 0.001, 0, false);
      box(TABLE.hw * 2, 0.002, 0.02, white, 0, 0.001, s * (TABLE.hl - 0.01), false);
    });
    box(0.004, 0.002, TABLE.hl * 2, white, 0, 0.001, 0, false);
    const legMat = std(0x222831, 0.6, 0.4);
    [-1, 1].forEach(sx => [-1, 1].forEach(sz => {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.72, 12), legMat);
      leg.position.set(sx * (TABLE.hw - 0.12), -0.4, sz * (TABLE.hl - 0.2)); leg.castShadow = true; S.add(leg);
    }));
    // Net: translucent mesh + top tape + posts
    const mesh = new THREE.Mesh(new THREE.PlaneGeometry(TABLE.hw * 2 + 0.3, TABLE.netH),
      new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, side: THREE.DoubleSide, roughness: 1 }));
    mesh.position.y = TABLE.netH / 2; S.add(mesh);
    box(TABLE.hw * 2 + 0.3, 0.012, 0.004, white, 0, TABLE.netH, 0);
    [-1, 1].forEach(s => box(0.016, TABLE.netH + 0.02, 0.016, std(0x888e99, 0.4, 0.6), s * (TABLE.hw + 0.15), TABLE.netH / 2, 0));

    this.ballMesh = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 24, 16),
      new THREE.MeshStandardMaterial({ color: 0xffe2b8, emissive: 0xff8a2a, emissiveIntensity: 0.55, roughness: 0.4 }));
    this.ballMesh.castShadow = true; S.add(this.ballMesh);

    this.composer = new EffectComposer(R);
    this.composer.addPass(new RenderPass(S, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.35, 0.5, 0.9);
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());
  }

  makePaddle(color, z) {
    const g = new THREE.Group();
    const face = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.085, 0.012, 32),
      new THREE.MeshStandardMaterial({ color, roughness: 0.55 }));
    face.rotation.x = Math.PI / 2;
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.09, 0.014),
      new THREE.MeshStandardMaterial({ color: 0xc89b6d, roughness: 0.7 }));
    handle.position.y = -0.125;
    g.add(face, handle); g.traverse(o => { o.castShadow = true; });
    this.scene.add(g);
    return { mesh: g, pos: new THREE.Vector3(0, 0.25, z), vel: new THREE.Vector3(), t: 1, power: 0.5, reach: 0.13, baseZ: z };
  }

  resize() {
    const w = innerWidth, h = innerHeight;
    this.renderer.setSize(w, h); this.composer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.fov = w / h < 1 ? 72 : 50;
    this.camera.updateProjectionMatrix();
  }

  // ---------- flow ----------
  start(level) {
    this.ai = new AI(level);
    this.score = { player: 0, ai: 0 };
    this.ui.hideMenu();
    this.startServe();
  }
  get server() {
    const t = this.score.player + this.score.ai;
    const i = t >= 20 ? t % 2 : Math.floor(t / 2) % 2; // alternate every point from 10-10
    return i === 0 ? this.first : other(this.first);
  }
  startServe() {
    this.state = 'serve'; this.lastHitter = null; this.timer = 1.1;
    this.ball.vel.set(0, 0, 0); this.ball.spin.set(0, 0, 0);
    this.ai.notifyHit();
    this.ui.score(this.score.player, this.score.ai, this.server);
    this.ui.message(this.server === 'player' ? 'Your serve — hold, release to hit' : 'CPU serving…', 1600);
  }
  onSwing(power) {
    if (this.state === 'menu' || this.state === 'over') return;
    this.pp.t = 0; this.pp.power = power;
    if (this.state === 'serve' && this.server === 'player') this.launch('player', power, this.controls.x * 0.5);
  }
  launch(who, power, aimX) {
    const pd = who === 'player' ? this.pp : this.ap;
    strike(this.ball, who === 'player' ? -1 : 1, power, aimX, pd.vel);
    this.lastHitter = who; this.bouncedOpp = false; this.cool = 0.25; this.state = 'rally';
    this.sfx.hit();
    if (who === 'player') this.ai.notifyHit();
  }
  tryHit(who) {
    const pd = who === 'player' ? this.pp : this.ap, dir = who === 'player' ? -1 : 1, b = this.ball;
    if (this.lastHitter === who || this.cool > 0) return;
    if (Math.hypot(b.pos.x - pd.pos.x, b.pos.y - pd.pos.y) > pd.reach) return;
    if (Math.abs(b.pos.z - pd.pos.z) > 0.14 || b.vel.z * dir > 0) return;
    if (who === 'player') {
      const power = pd.t < 1 ? pd.power : 0.3; // passive block if not swinging
      this.launch('player', power, clamp(pd.vel.x * 0.25 + (b.pos.x - pd.pos.x) * 5, -0.65, 0.65));
    } else {
      pd.t = 0;
      this.launch('ai', this.ai.power, this.ai.aim(this.pp.pos.x));
    }
  }
  onEvent(ev) {
    if (ev.type === 'net') return this.sfx.net();
    if (ev.type === 'table') {
      this.sfx.bounce();
      if (ev.side === this.lastHitter) this.point(other(this.lastHitter));      // bounced on own side
      else if (this.bouncedOpp) this.point(this.lastHitter);                    // double bounce
      else this.bouncedOpp = true;
    } else if (ev.type === 'floor') {
      this.point(this.bouncedOpp ? this.lastHitter : other(this.lastHitter));   // miss or out
    }
  }
  point(winner) {
    if (this.state !== 'rally') return;
    this.score[winner]++; this.state = 'point'; this.wait = 1.4;
    this.sfx.score(winner === 'player');
    const { player: p, ai: a } = this.score;
    this.ui.score(p, a, this.server);
    if ((p >= WIN || a >= WIN) && Math.abs(p - a) >= 2) {
      this.state = 'over';
      const won = p > a;
      this.ui.showMenu(won ? 'You win' : 'CPU wins', `Final score ${p} – ${a}`, 'Play again');
    } else this.ui.message(winner === 'player' ? 'Point — you' : 'Point — CPU', 1200);
  }

  // ---------- loop ----------
  frame(now) {
    requestAnimationFrame(t => this.frame(t));
    const dt = Math.min(0.033, (now - this.last) / 1000); this.last = now;
    this.update(dt, now / 1000);
    this.composer.render();
  }
  update(dt, time) {
    const c = this.controls, pp = this.pp, ap = this.ap, ball = this.ball;
    c.update(dt); this.ui.charge(c.charging && this.state !== 'menu' ? c.charge : 0);

    // Player paddle follows the cursor with smoothing; velocity drives spin
    const prev = pp.pos.clone(), k = 1 - Math.exp(-20 * dt);
    pp.pos.x += (clamp(c.x * 0.95, -1.1, 1.1) - pp.pos.x) * k;
    pp.pos.y += (0.08 + c.y * 0.55 - pp.pos.y) * k;
    if (pp.t < 1) pp.t = Math.min(1, pp.t + dt / 0.22);
    pp.pos.z = PADDLE_Z - 0.28 * Math.sin(Math.PI * pp.t) + (c.charging ? 0.1 * c.charge : 0);
    pp.vel.copy(pp.pos).sub(prev).divideScalar(dt);

    const aprev = ap.pos.clone();
    this.ai.update(dt, ball, ap, this.state === 'rally' && this.lastHitter === 'player');
    if (ap.t < 1) ap.t = Math.min(1, ap.t + dt / 0.22);
    ap.pos.z = -PADDLE_Z + 0.28 * Math.sin(Math.PI * ap.t);
    ap.vel.copy(ap.pos).sub(aprev).divideScalar(dt);
    for (const p of [pp, ap]) {
      p.mesh.position.copy(p.pos); p.reach = p === ap ? this.ai.cfg.reach : 0.13;
      p.mesh.rotation.x = -0.35 * Math.sin(Math.PI * p.t) * (p === pp ? 1 : -1);
    }

    if (this.state === 'serve') {
      const sp = this.server === 'player' ? pp : ap, d = this.server === 'player' ? -1 : 1;
      ball.pos.set(sp.pos.x, sp.pos.y + 0.05, sp.pos.z + d * 0.08);
      if (this.server === 'ai' && (this.timer -= dt) <= 0) this.launch('ai', 0.5, (Math.random() * 2 - 1) * 0.5);
    } else if (this.state !== 'menu') {
      this.cool -= dt;
      const n = 4;
      for (let i = 0; i < n; i++) {
        for (const ev of ball.step(dt / n)) this.onEvent(ev);
        if (this.state === 'rally') { this.tryHit('player'); this.tryHit('ai'); }
      }
      if (this.state === 'point' && (this.wait -= dt) <= 0) this.startServe();
    } else {
      ball.pos.set(0, 0.25 + 0.04 * Math.sin(time * 2), 0.6); // idle on the menu
    }
    this.ballMesh.position.copy(ball.pos);

    // Camera: gentle sway on the menu, light tracking during play
    const cam = this.camera, back = this.camera.aspect < 1 ? 3.3 : 2.55;
    const cx = this.state === 'menu' ? Math.sin(time * 0.3) * 0.9 : pp.pos.x * 0.25;
    cam.position.x += (cx - cam.position.x) * Math.min(1, dt * 3);
    cam.position.set(cam.position.x, 0.72, back);
    cam.lookAt(0, 0.05, -0.35);
  }
}
