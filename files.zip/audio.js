/** Web Audio synthesized sound effects — no external assets. */
export class Sfx {
  constructor() { this.ctx = null; }
  unlock() {
    this.ctx ??= new (window.AudioContext || window.webkitAudioContext)();
    this.ctx.resume();
  }
  tone(freq, dur, type = 'sine', gain = 0.2, slide = 0, delay = 0) {
    const c = this.ctx; if (!c) return;
    const t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + dur);
  }
  hit()    { this.tone(1100, 0.05, 'triangle', 0.25, -500); }
  bounce() { this.tone(330, 0.07, 'sine', 0.3, -150); }
  net()    { this.tone(140, 0.1, 'sawtooth', 0.12); }
  score(win) { (win ? [523, 659, 784] : [392, 330, 262]).forEach((f, i) => this.tone(f, 0.25, 'sine', 0.15, 0, i * 0.1)); }
}
